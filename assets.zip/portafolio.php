<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/funciones.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <!-- background-image:url(https://cdn.pixabay.com/photo/2018/02/11/09/43/block-chain-3145376_960_720.jpg)-->

    <title>Mi pagina Web</title>
</head>
<body class="bg-dark " style="min-height:600px">

<div class="" style="height: 100px;">
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark w-100 " style="position: fixed;z-index: 1">
  <div class="container-fluid w-100">
    <a class="navbar-brand" href="#"><img class="gradient-box img-fluid rounded rounded-circle" style="width:60px;text-align:right ; margin-top: 0;" src="assets/images/perfiladrian.png"  ></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse w-100" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 d-flex">
            <li class="nav-item mt-5">
            <a class="nav-link mx-3" href="#perfil">Acerca de mi</a>
            </li>
            <li class="nav-item mt-5">
            <a class="nav-link mx-3" href="#conocimiento">Conocimientos</a>
            </li>
            <li class="nav-item mt-5">
            <a class="nav-link mx-3" href="#certificado">Certificados</a>
            </li>
            <li class="nav-item mt-5">
            <a class="nav-link mx-3" href="#experiencia">Experiencia</a>
            </li>
            <li class="nav-item mt-5">
            <a class="nav-link mx-3" href="#proyectos">Proyectos</a>
            
            </li>
            <li class="nav-item mt-5">
            <a class="nav-link mx-3" href="#contactos">Contactos</a>
            
            </li>
      </ul>
      
    </div>
  </div>
</nav>
</div>


    
    <div class="container bg-dark " style="height:fit-content;">
        <div class="w-100 bg-dark" style="min-height: 700px;">
            <div class="row p-3 m-2" id="perfil">
                <h1 style="text-align: center; color:white; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"><strong>Hola</strong></h1>
                <br>
                <p style="text-align: center; color:white; font-size: 25pt;">Mi nombre es  <strong>ADRIAN CRISTIAN RAYME</strong> </p>
                <div id="perfil" class=" text-center col-sm " > 
                    <div class=" p-1">
                        <br>
                        <img class="gradient-box img-fluid " style="  border-radius: 200pt;" src="assets/images/perfiladrian.png"  > 
                        <br>
                        <br>
                        <p style="text-align: center; color:white; font-size: larger;">Bachiller en ingenieria Informatica y de Sistemas</p>
                      
                        <button id="btnmasinfo" class="btn bg-info m-4 p-2 w-25" style="color: white;" onclick="masinfo()"> <strong> Mas</strong></button>
                    </div>
                </div>
                <div id="detalle" class="col-sm text-center m-auto" style="display: none;" >
                <div class="p-1 m-auto">
                    
                        <h1 style="text-align: center; color:white">Detalle</h1>
                        <br>
                        <p class=" m-4" style="text-align: justify; color:white; font-size:16pt">Estudie en la Universidad San Ignacio de Loyola,Lima-Peru, en el periodo de 2015-2020. Actualmente, trabajo en la empresa Dimos Peru como asistente de sistemas. 
                        En la cual mis principales funciones son el desarrollo de soluciones para puntos de venta (Ventas, compras, inventarios, reportes, base datos y facturacion electronica).</p>
                        <br>
                        <button id="btnmmenosinfo" class="btn bg-info m-4 p-2 w-25" style="color: white;" onclick="menosinfo()"><strong> Menos</strong></button>
                    </div>
                </div>
            </div>
            
           <div class="row p-3 m-2" id="conocimiento">
                <br>
               <h1 style="text-align: center; color:white;text-decoration: underline gray;">Mis Conocimientos</h1> 
             <br>
             <br>
             <br>
             <br>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://d2vqpl3tx84ay5.cloudfront.net/tumblr_lsus01g1ik1qies3uo1_400.png" width="100px"> <button class="btn w-100 b-0" style="color: yellow;">Javascript</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://aspnetcoremaster.com/img/csharp.webp" width="100px"><button class="btn  w-100 b-0" style="color: blueviolet;">C#.Net</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://techcommunity.microsoft.com/t5/image/serverpage/image-id/283585i32E35734ADB2BDF9" width="100px"> <button class="btn  w-100 b-0" style="color: skyblue;">SQL</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://ventiv.solutions/wp-content/uploads/2021/02/mySQL-logo.png" width="100px"><button class="btn  w-100 b-0" style="color: orange;">MySql</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/HTML5_logo_and_wordmark.svg/2048px-HTML5_logo_and_wordmark.svg.png" width="100px"> <button class="btn  w-100 b-0" style="color: orange;">HTML</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://cdn-icons-png.flaticon.com/512/919/919826.png" width="100px"><button class="btn  w-100 b-0" style="color: skyblue;">CSS</button></div>
            
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://play-lh.googleusercontent.com/5e7z5YCt7fplN4qndpYzpJjYmuzM2WSrfs35KxnEw-Ku1sClHRWHoIDSw3a3YS5WpGcI" width="100px"> <button class="btn w-100 b-0" style="color: skyblue;">Flutter</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://img.freepik.com/premium-vector/bootstrap-icon-b-letter-logo_781017-7.jpg" width="100px"><button class="btn  w-100 b-0" style="color: blueviolet;">Bootstrap</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://w7.pngwing.com/pngs/106/833/png-transparent-dart-logo-programming-language-computer-programming-android-text-logo-computer-programming-thumbnail.png" width="100px"> <button class="btn  w-100 b-0" style="color: skyblue;">Dart</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Webysther_20160423_-_Elephpant.svg/2560px-Webysther_20160423_-_Elephpant.svg.png" width="150px"><button class="btn  w-100 b-0" style="color: blueviolet;">PHP</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://d1yjjnpx0p53s8.cloudfront.net/styles/logo-thumbnail/s3/092011/jquery.png?itok=Yh7GpHmE" width="100px"> <button class="btn  w-100 b-0" style="color: white;">Jquery</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://geeks.ms/jorge/wp-content/uploads/sites/6/2007/05/20210927_01.png" width="100px"><button class="btn  w-100 b-0" style="color: skyblue;">Scrum</button></div>

            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://icones.pro/wp-content/uploads/2021/06/icone-github-violet.png" width="100px"> <button class="btn w-100 b-0" style="color: blueviolet;">GitHub</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://cdn.icon-icons.com/icons2/691/PNG/512/google_firebase_icon-icons.com_61475.png" width="100px"><button class="btn  w-100 b-0" style="color: yellow;">Firebase</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Visual_Studio_Icon_2022.svg/1200px-Visual_Studio_Icon_2022.svg.png" width="100px"> <button class="btn  w-100 b-0" style="color: blueviolet;">Visual Studio</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://db.cs.uni-tuebingen.de/teaching/ws2223/sql-is-a-programming-language/logo.svg" width="100px"><button class="btn  w-100 b-0" style="color: blueviolet;">SQL</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://cdn-icons-png.flaticon.com/512/6394/6394065.png" width="100px"> <button class="btn  w-100 b-0" style="color: white;">Json</button></div>
            <div class="col-sm-2 text-center"> <img class="img-fluid" src="https://seeklogo.com/images/I/insomnia-logo-A35E09EB19-seeklogo.com.png" width="100px"><button class="btn  w-100 b-0" style="color: blueviolet;">Apis</button></div>

           </div>
           <br>
           <div class=" row p-3 m-2" id="certificado">
           <br>
            <h1 style="text-align: center; color:white;text-decoration: underline gray;">Mis Certificados</h1>
            <div class="row my-3 ">
                    <div class="col-sm-6">
                    <img class="img-fluid p-5" src="assets/images/cert1.png" alt="" >
                    </div>
                    <div  class="col-sm-6 text-center mt-5">
                        <h3 style="color:white">Agile course</h3>
                        <p style="color:gray">Desde 31 de Diciembre de 2019 </p>
                        <p style="color:white">Tranformacion digital:Retos y tendencias.</p>
                        <br>
                        <button class="btn bg-info">Mas &nbsp +</button>
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6 text-center mt-5">
                    <h3 style="color:white">Excel Intermedio</h3>
                    <p style="color:gray">Desde 31 de Diciembre de 2019 </p>
                    <p style="color:white">Analisis y presentacion de datos</p>
                    <br>
                    <button  class="btn bg-info"  >Mas &nbsp +</button>
                    </div>
                    <div  class="col-sm-6 p-5">
                        <img class="img-fluid" src="assets/images/cert2.png" alt="">
                    </div>
                </div>

           </div>
           <br>
           <div class="row p-3 m-2" id="experiencia">
           <br>
            <h1 style="text-align: center; color:white ;text-decoration: underline gray;">Mi Experiencia</h1>
            <br>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <img class="img-fluid p-5" src="https://www.dimosperu.com.pe/assets/images/main.PNG" alt="">
                    </div>
                    <div  class="col-sm-6">
                        <h3 style="color:white">Practicante de Sistemas Dimos Peru SAC</h3>
                        <p style="color:gray">Desde 4 enero de 2021 hasta 30 agosto 2021</p>
                        <p style="color:white">Diseño y Desarollo de Pagina Web y Sistema Punto de venta multisucursal(aplicacion de escritorio), con base de datos local y
                         nube con el lenguaje C# winforms (modelo de 3 capas) y MySql.</p>
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <h3 style="color:white">Asistente de Sistemas Dimos Peru SAC</h3>
                    <p style="color:gray">Desde 30 de agosto de 2021 hasta presente</p>
                    <p style="color:white">Despliegue Sistema Punto de venta multisucursal(productos, compras, ventas, inventarios, clientes, proveedores, gastos, 
                        reportes gerenciales y administrativos, facturacion electronica, kardex, gestion de precios y descuentos), implementacion de facturacion electronica,capacitacion a personal,
                         soporte a tiendas y mejora de funcionalidades.</p>
                    </div>
                    <div  class="col-sm-6">
                        <img  src="https://www.dimosperu.com.pe/assets/images/main.PNG" alt="">
                    </div>
                </div>
           </div>
           <br>
           <div class="row p-3 m-2" id="proyectos">
           <br>
            <h1 style="text-align: center; color:white ;text-decoration: underline gray;">Mis Proyectos</h1>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <img class="img-fluid p-5" src="assets/images/sisventas.png" alt="">
                    </div>
                    <div  class="col-sm-6">
                        <h3 style="color:white">Sistema Punto de venta multisucursal</h3>
                        <p style="color:gray">Desde 4 enero de 2021</p>
                        <p style="color:white">Sistema Punto de venta multisucursal(productos, compras, ventas, inventarios, clientes, proveedores, gastos, 
                        reportes gerenciales y administrativos, facturacion electronica, kardex, gestion de precios y descuentos), implementacion de facturacion electronica,capacitacion a personal,
                         soporte a tiendas y mejora de funcionalidades. Desarrollado con C# Windows Forms con modelo de 3 capas(Datos, Negocio y Presentacion) y
                          cuenta con base datos en Mysql(tablas y procedimientos).</p>
                          <a href="">Ver Demo</a>
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <h3 style="color:white">Pagina web Dimos Peru</h3>
                    <p style="color:gray">Desde 1 marzo 2021</p>
                    <p style="color:white">Diseño y desarrollo de pagina web informativa de la empresa Dimos Peru Sac, cuenta con 4 secciones las cuales son inicio, productos, ofertas y contactos. 
                    Desarrollado en VSCODE con hmtl, css,boostrap,jquery, javascript y php.</p>
                    <a href="https://dimosperu.com.pe/">Ir a Pagina</a>
                    </div>
                    <div  class="col-sm-6">
                        <img class="img-fluid p-5" src="assets/images/webdimos.png" alt="">
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <img class="img-fluid p-5" src="assets/images/corpmarkos.png" alt="">
                    </div>
                    <div  class="col-sm-6">
                        <h3 style="color:white">Pagina web Corpotacion Markos</h3>
                        <p style="color:gray">Desde 1 junio de 2022</p>
                        <p style="color:white">Diseño y desarrollo de pagina web informativa de la empresa Dimos Peru Sac, cuenta con 4 secciones las cuales son inicio, productos, ofertas y contactos. 
                    Desarrollado en VSCODE con hmtl, css,boostrap,jquery, javascript y php.</p>
                    <a href="https://corpmarkos.com.pe/">Ir a Pagina</a>
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <h3 style="color:white">Sistema de Alquileres</h3>
                    <p style="color:gray">Desde 1 de agosto de 2021</p>
                    <p style="color:white">Aplicacion MVC para la gestion de alquiler de cuartos y departamentos, contratos y cobranzas.</p>
                    <a href="">Ver Demo</a>
                    </div>
                    <div  class="col-sm-6">
                        <img class="img-fluid p-5" src="assets/images/sistemaalquileres.png" alt="">
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <img class="img-fluid p-5" src="assets/images/euroexotic.png" alt="">
                    </div>
                    <div  class="col-sm-6">
                        <h3 style="color:white">Landing Page Euro exotic</h3>
                        <p style="color:gray">Desde 1 enero de 2019</p>
                        <p style="color:white">Diseño y desarrollo de landing page de la empresa Euro Exotic Sac, 
                          Desarrollado en VSCODE con hmtl, css y boostrap.</p>
                          <a href="https://rssystemsolutions.com.pe">Ir a Pagina</a>
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <h3 style="color:white">Aplicacion movil de Salud USIL</h3>
                    <p style="color:gray">Desde 20 de agosto de 2020</p>
                    <p style="color:white">Diseño y desarrollo de la aplicacion movil Ideal Covid. Cuenta con secciones de busqueda de hospitales, triaje, noticias y consulta con el doctor.</p>
                    <a href="">Ver demo</a>
                    </div>
                    <div  class="col-sm-6">
                        <img class="img-fluid p-5" src="assets/images/appusil.png" alt="">
                    </div>
                </div>
                <div class="row my-3 ">
                    <div class="col-sm-6">
                    <img class="img-fluid p-5" src="assets/images/jmmovil.png" alt="">
                    </div>
                    <div  class="col-sm-6">
                        <h3 style="color:white">Aplicacion movil escuelas</h3>
                        <p style="color:gray">Desde Agosto 2020</p>
                        <p style="color:white">Diseño y desarrollo de la aplicacion movil de escuelas el cual presentaba el registro de usuarios, cursos, horarios y notas.</p>
                        <a href="">Ver demo</a>
                    </div>
                </div>
           </div>
           <br>

        </div>
    </div>
    <div class="jumbotron  bg-dark" id= "contactos" style="margin-bottom:0">
    <div class="container bg-dark" style="color:white">
    <div class="row">
    <div class="col-sm m-auto text-center">
    <img class="gradient-box img-fluid rounded rounded-circle" style="width:60px;text-align:right ; margin-top: 0;" src="assets/images/perfiladrian.png"  >

    </div>

    <div class="col-sm"> 
        <div id="foder">
          <h3 id="fg" class="text-center">Mas Informacion</h3>
          <br>
                <ul>
                <li>
                    <h5>Correos:</h5> 
                    <a> &nbsp adrian.rayme.ospina@gmail.com</a> <br>
                    <a> &nbsp reyfn@hotmail.com</a> <br>
                    <a> &nbsp reyfn21@gmail.com</a> 
                </li>
                <li>
                <h5>Contacto:</h5> 
                    <a> &nbsp 975918915</a> 
                </li>
                <li>
                <h5>Ubicacion:</h5> 
                    <a> &nbsp Lima,Peru</a> 
                </li>
                <li>
                    <h5>Horario:</h5> 
                    <a> &nbsp De Lunes a Viernes,7:00 am a 9:00 pm y Sábado 7:00 am a 1:00 pm</a> 
                </li>
                </ul>               
        </div>
    </div>
    <div class="col-sm m-auto p-auto">    
    <div class="text-center m-auto p-auto">
                    <ul>
                        <li><a href="" style="color:white"><img src ="https://content.linkedin.com/content/dam/me/business/en-us/amp/brand-site/v2/bg/LI-Bug.svg.original.svg" width="25"> &nbsp Linkedin</a></li>
                        <li><a href="" style="color:white"><img src ="https://cdn-icons-png.flaticon.com/512/4205/4205993.png" width="25"> &nbsp Web Page</a></li>
                        <li><a href="" style="color:white"><img src ="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png" width="25"> &nbsp Github</a></li>
                    </ul>
                </div>
    </div>
    </div>
    <br><br>
    <footer id="footer" class="text-center" >
            <p id="foot1" class="m-auto">
            @Adrian Cristian Rayme Ospina
            </p>
        </footer>
    </div>
</body>
</html>
